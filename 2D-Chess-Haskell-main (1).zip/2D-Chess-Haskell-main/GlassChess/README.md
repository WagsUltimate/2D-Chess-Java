# GlassChess (Haskell Port)

Haskell mirror of the `2D-Chess-Java-main/2D-Chess-Java-main/GlassChess` project structure, matching the Java modules (`Side`, `PieceType`, `Position`, `Piece`, `Move`, `Board`, `ChessGame`, `ChessPanel`, `Main`, `ChessTests`, and `RenderPreview`) and asset filenames in `GlassChess/assets/`.

## Layout

```text
2D-Chess-Haskell-main/
├── .gitattributes
├── .gitignore
└── GlassChess/
    ├── GlassChess.cabal
    ├── README.md
    ├── run.bat
    ├── run.sh
    ├── test.bat
    ├── test.sh
    ├── assets/
    │   ├── board.png
    │   ├── black_bishop.png ... black_rook.png
    │   └── white_bishop.png ... white_rook.png
    ├── src/
    │   ├── Main.hs
    │   └── Chess/
    │       ├── Side.hs
    │       ├── PieceType.hs
    │       ├── Position.hs
    │       ├── Piece.hs
    │       ├── Move.hs
    │       ├── Board.hs
    │       └── ChessGame.hs
    └── tests/
        └── Chess/
            ├── ChessTests.hs
            └── RenderPreview.hs
```

## Build & Run

```bash
cabal run glass-chess
cabal test
```
