#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
cabal run glass-chess
