module Chess.RenderPreview
  ( previewAssets
  ) where

import qualified Data.Map.Strict as Map
import Chess.Board (boardAssetPath)
import Chess.Piece (pieceAssetPath)
import Chess.ChessGame (ChessGame(..), newGame)

previewAssets :: ChessGame -> [FilePath]
previewAssets g =
  boardAssetPath : [ pieceAssetPath pc | (_, pc) <- Map.toList (gameBoard g) ]

defaultPreview :: [FilePath]
defaultPreview = previewAssets newGame
