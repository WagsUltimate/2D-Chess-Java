module Main where

import Control.Monad (unless)
import System.Exit (exitFailure)
import Chess.Side (Side(..))
import Chess.Position (Position(..), fromAlgebraic, toAlgebraic)
import Chess.Piece (Piece(..), pieceAssetPath)
import Chess.Move (Move(..))
import Chess.Board (boardAssetPath, pieceAt)
import Chess.ChessGame (GameStatus(..), ChessGame(..), newGame, applyMove, legalMovesFrom)

assertBool :: String -> Bool -> IO ()
assertBool msg cond = unless cond $ do
  putStrLn ("FAIL: " ++ msg)
  exitFailure

main :: IO ()
main = do
  assertBool "board asset path" (boardAssetPath == "assets/board.png")
  assertBool "white king asset path" (pieceAssetPath (Piece White King) == "assets/white_king.png")
  assertBool "black queen asset path" (pieceAssetPath (Piece Black Queen) == "assets/black_queen.png")

  let e2 = fromAlgebraic "e2"
      e4 = fromAlgebraic "e4"
  assertBool "e2 parses" (e2 == Just (Position 6 4))
  assertBool "e4 parses" (e4 == Just (Position 4 4))
  assertBool "e4 formats" (toAlgebraic (Position 4 4) == Just "e4")

  let g0 = newGame
  assertBool "white starts" (currentTurn g0 == White)
  assertBool "white pawn at e2 has 2 legal moves" (length (legalMovesFrom g0 (Position 6 4)) == 2)
  assertBool "white knight at g1 has 2 legal moves" (length (legalMovesFrom g0 (Position 7 6)) == 2)

  let m1 = Move (Position 6 4) (Position 4 4) Nothing
  case applyMove g0 m1 of
    Left err -> assertBool ("valid e2e4 rejected: " ++ err) False
    Right g1 -> do
      assertBool "turn switches to Black" (currentTurn g1 == Black)
      assertBool "pawn moved to e4" (pieceAt (gameBoard g1) (Position 4 4) == Just (Piece White Pawn))
      assertBool "e2 now empty" (pieceAt (gameBoard g1) (Position 6 4) == Nothing)

  putStrLn "All GlassChess tests passed."
