module Main where

import qualified Data.Map.Strict as Map
import Data.Char (toLower)
import System.IO (hFlush, stdout)
import Chess.Side (Side(..))
import Chess.Position (Position(..), fromAlgebraic, toAlgebraic)
import Chess.Piece (Piece(..), pieceAssetPath, pieceUnicode)
import Chess.Move (Move(..))
import Chess.Board (Board, boardAssetPath)
import Chess.ChessGame
  ( GameStatus(..)
  , ChessGame(..)
  , newGame
  , applyMove
  )

renderBoard :: Board -> String
renderBoard b = unlines $
  [ "Board asset: " ++ boardAssetPath
  , "    a   b   c   d   e   f   g   h"
  ] ++ [ renderRow r | r <- [0..7] ] ++ [ "    a   b   c   d   e   f   g   h" ]
  where
    renderRow r =
      let rank = show (8 - r) ++ " "
          cells = [ cell r c | c <- [0..7] ]
      in rank ++ unwords cells ++ " " ++ show (8 - r)
    cell r c =
      case Map.lookup (Position r c) b of
        Just pc -> "[" ++ [pieceUnicode pc] ++ "]"
        Nothing -> " . "

parseMoveStr :: String -> Maybe Move
parseMoveStr raw =
  let cleaned = filter (/= ' ') (map toLower raw)
  in case cleaned of
       [f1, r1, f2, r2] -> do
         from <- fromAlgebraic [f1, r1]
         to   <- fromAlgebraic [f2, r2]
         return (Move from to Nothing)
       _ -> Nothing

loop :: ChessGame -> IO ()
loop g = do
  putStrLn ""
  putStrLn (renderBoard (gameBoard g))
  case gameStatus g of
    Check s     -> putStrLn ("Check on " ++ show s ++ "!")
    Checkmate w -> putStrLn ("Checkmate! " ++ show w ++ " wins.")
    Stalemate   -> putStrLn "Stalemate! Draw."
    InProgress  -> return ()

  case gameStatus g of
    Checkmate _ -> return ()
    Stalemate   -> return ()
    _ -> do
      putStr (show (currentTurn g) ++ " move (e.g. e2 e4, 'assets', or 'quit'): ")
      hFlush stdout
      line <- getLine
      let cmd = map toLower (unwords (words line))
      if cmd == "quit" || cmd == "exit"
        then putStrLn "Exiting GlassChess."
        else if cmd == "assets"
          then do
            mapM_ (\(pos, pc) -> putStrLn (maybe "??" id (toAlgebraic pos) ++ ": " ++ pieceAssetPath pc))
                  (Map.toList (gameBoard g))
            loop g
          else case parseMoveStr line of
            Nothing -> do
              putStrLn "Invalid input. Enter coordinates like e2 e4."
              loop g
            Just mv -> case applyMove g mv of
              Left err -> do
                putStrLn err
                loop g
              Right g' -> loop g'

main :: IO ()
main = do
  putStrLn "=== GlassChess (Haskell) ==="
  loop newGame
