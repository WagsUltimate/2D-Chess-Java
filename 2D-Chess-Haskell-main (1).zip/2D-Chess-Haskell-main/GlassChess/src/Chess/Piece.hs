module Chess.Piece
  ( Piece(..)
  , pieceAssetPath
  , pieceUnicode
  ) where

import Chess.Side (Side(..))
import Chess.PieceType (PieceType(..))

data Piece = Piece
  { pieceSide :: Side
  , pieceKind :: PieceType
  } deriving (Eq, Ord, Show, Read)

pieceAssetPath :: Piece -> FilePath
pieceAssetPath (Piece side kind) =
  let prefix = case side of
        White -> "white_"
        Black -> "black_"
      name = case kind of
        King   -> "king.png"
        Queen  -> "queen.png"
        Rook   -> "rook.png"
        Bishop -> "bishop.png"
        Knight -> "knight.png"
        Pawn   -> "pawn.png"
  in "assets/" ++ prefix ++ name

pieceUnicode :: Piece -> Char
pieceUnicode (Piece White King)   = '♔'
pieceUnicode (Piece White Queen)  = '♕'
pieceUnicode (Piece White Rook)   = '♖'
pieceUnicode (Piece White Bishop) = '♗'
pieceUnicode (Piece White Knight) = '♘'
pieceUnicode (Piece White Pawn)   = '♙'
pieceUnicode (Piece Black King)   = '♚'
pieceUnicode (Piece Black Queen)  = '♛'
pieceUnicode (Piece Black Rook)   = '♜'
pieceUnicode (Piece Black Bishop) = '♝'
pieceUnicode (Piece Black Knight) = '♞'
pieceUnicode (Piece Black Pawn)   = '♟'
