module Chess.Position
  ( Position(..)
  , isValidPosition
  , fromAlgebraic
  , toAlgebraic
  ) where

import Data.Char (toLower)

data Position = Position
  { posRow :: Int
  , posCol :: Int
  } deriving (Eq, Ord, Show, Read)

isValidPosition :: Position -> Bool
isValidPosition (Position r c) = r >= 0 && r < 8 && c >= 0 && c < 8

fromAlgebraic :: String -> Maybe Position
fromAlgebraic [f, rk] =
  let col = fromEnum (toLower f) - fromEnum 'a'
      row = 8 - (fromEnum rk - fromEnum '1')
      p   = Position row col
  in if isValidPosition p then Just p else Nothing
fromAlgebraic _ = Nothing

toAlgebraic :: Position -> Maybe String
toAlgebraic p@(Position r c)
  | not (isValidPosition p) = Nothing
  | otherwise =
      let fileCh = toEnum (fromEnum 'a' + c)
          rankCh = toEnum (fromEnum '1' + (7 - r))
      in Just [fileCh, rankCh]
