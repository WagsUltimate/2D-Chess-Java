module Chess.Side
  ( Side(..)
  , oppositeSide
  ) where

data Side = White | Black
  deriving (Eq, Ord, Show, Read, Enum, Bounded)

oppositeSide :: Side -> Side
oppositeSide White = Black
oppositeSide Black = White
