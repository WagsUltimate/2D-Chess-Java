module Chess.PieceType
  ( PieceType(..)
  ) where

data PieceType = King | Queen | Rook | Bishop | Knight | Pawn
  deriving (Eq, Ord, Show, Read, Enum, Bounded)
