module Chess.ChessGame
  ( GameStatus(..)
  , ChessGame(..)
  , newGame
  , isPseudoLegalMove
  , isLegalMove
  , legalMovesFrom
  , isSquareAttacked
  , isInCheck
  , applyMove
  ) where

import qualified Data.Map.Strict as Map
import Chess.Side (Side(..), oppositeSide)
import Chess.PieceType (PieceType(..))
import Chess.Position (Position(..), isValidPosition)
import Chess.Piece (Piece(..))
import Chess.Move (Move(..))
import Chess.Board (Board, initialBoard, movePiece, isPathClear)

data GameStatus
  = InProgress
  | Check Side
  | Checkmate Side
  | Stalemate
  deriving (Eq, Show)

data ChessGame = ChessGame
  { gameBoard    :: Board
  , currentTurn  :: Side
  , gameStatus   :: GameStatus
  , moveHistory  :: [Move]
  , selectedPos  :: Maybe Position
  } deriving (Eq, Show)

newGame :: ChessGame
newGame = ChessGame
  { gameBoard   = initialBoard
  , currentTurn = White
  , gameStatus  = InProgress
  , moveHistory = []
  , selectedPos = Nothing
  }

allPositions :: [Position]
allPositions = [Position r c | r <- [0..7], c <- [0..7]]

isPseudoLegalMove :: Board -> Move -> Bool
isPseudoLegalMove b (Move from@(Position r1 c1) to@(Position r2 c2) _)
  | from == to || not (isValidPosition from) || not (isValidPosition to) = False
  | otherwise = case Map.lookup from b of
      Nothing -> False
      Just (Piece s pt) ->
        let blockedByFriendly = maybe False ((== s) . pieceSide) (Map.lookup to b)
        in not blockedByFriendly && case pt of
             King ->
               abs (r2 - r1) <= 1 && abs (c2 - c1) <= 1
             Knight ->
               let dr = abs (r2 - r1)
                   dc = abs (c2 - c1)
               in (dr == 2 && dc == 1) || (dr == 1 && dc == 2)
             Rook ->
               (r1 == r2 || c1 == c2) && isPathClear b from to
             Bishop ->
               abs (r2 - r1) == abs (c2 - c1) && isPathClear b from to
             Queen ->
               (r1 == r2 || c1 == c2 || abs (r2 - r1) == abs (c2 - c1))
                 && isPathClear b from to
             Pawn ->
               let dir      = if s == White then -1 else 1
                   startRow = if s == White then 6 else 1
                   target   = Map.lookup to b
                   isEmpty  = maybe True (const False) target
                   isEnemy  = maybe False ((== oppositeSide s) . pieceSide) target
                   step1    = c2 == c1 && r2 == r1 + dir && isEmpty
                   step2    = c2 == c1 && r1 == startRow && r2 == r1 + 2 * dir
                                && isEmpty && isPathClear b from to
                   capture  = abs (c2 - c1) == 1 && r2 == r1 + dir && isEnemy
               in step1 || step2 || capture

findKing :: Board -> Side -> Maybe Position
findKing b s =
  case [p | (p, Piece ps pt) <- Map.toList b, ps == s && pt == King] of
    (k:_) -> Just k
    []    -> Nothing

isSquareAttacked :: Board -> Position -> Side -> Bool
isSquareAttacked b target bySide =
  any (\(pos, pc) -> pieceSide pc == bySide && isPseudoLegalMove b (Move pos target Nothing))
      (Map.toList b)

isInCheck :: Board -> Side -> Bool
isInCheck b s =
  case findKing b s of
    Nothing -> True
    Just k  -> isSquareAttacked b k (oppositeSide s)

applyMoveRaw :: Board -> Move -> Board
applyMoveRaw b (Move from to promo) =
  let moved = movePiece from to b
  in case Map.lookup to moved of
       Just (Piece s Pawn)
         | (s == White && posRow to == 0) || (s == Black && posRow to == 7) ->
             Map.insert to (Piece s (maybe Queen id promo)) moved
       _ -> moved

isLegalMove :: ChessGame -> Move -> Bool
isLegalMove g mv@(Move from _ _) =
  case Map.lookup from (gameBoard g) of
    Nothing -> False
    Just pc ->
      pieceSide pc == currentTurn g
        && isPseudoLegalMove (gameBoard g) mv
        && not (isInCheck (applyMoveRaw (gameBoard g) mv) (currentTurn g))

legalMovesFrom :: ChessGame -> Position -> [Move]
legalMovesFrom g from =
  [ Move from to Nothing
  | to <- allPositions
  , let mv = Move from to Nothing
  , isLegalMove g mv
  ]

hasAnyLegalMove :: Board -> Side -> Bool
hasAnyLegalMove b s =
  let probeGame = ChessGame b s InProgress [] Nothing
  in any (rom -> not (null (legalMovesFrom probeGame from)))
         [p | (p, pc) <- Map.toList b, pc == Piece s King || pieceSide pc == s]

computeStatus :: Board -> Side -> GameStatus
computeStatus b nextSide =
  let inChk    = isInCheck b nextSide
      canMove  = hasAnyLegalMove b nextSide
  in case (inChk, canMove) of
       (True, False)  -> Checkmate (oppositeSide nextSide)
       (False, False) -> Stalemate
       (True, True)   -> Check nextSide
       (False, True)  -> InProgress

applyMove :: ChessGame -> Move -> Either String ChessGame
applyMove g mv
  | not (isLegalMove g mv) = Left "Illegal move."
  | otherwise =
      let nextBoard = applyMoveRaw (gameBoard g) mv
          nextSide  = oppositeSide (currentTurn g)
          nextStat  = computeStatus nextBoard nextSide
      in Right ChessGame
           { gameBoard   = nextBoard
           , currentTurn = nextSide
           , gameStatus  = nextStat
           , moveHistory = moveHistory g ++ [mv]
           , selectedPos = Nothing
           }
