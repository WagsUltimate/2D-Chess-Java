module Chess.Board
  ( Board
  , boardAssetPath
  , emptyBoard
  , initialBoard
  , pieceAt
  , putPiece
  , removePiece
  , movePiece
  , isPathClear
  ) where

import qualified Data.Map.Strict as Map
import Chess.Side (Side(..))
import Chess.PieceType (PieceType(..))
import Chess.Position (Position(..), isValidPosition)
import Chess.Piece (Piece(..))

type Board = Map.Map Position Piece

boardAssetPath :: FilePath
boardAssetPath = "assets/board.png"

emptyBoard :: Board
emptyBoard = Map.empty

initialBoard :: Board
initialBoard = Map.fromList $
     backRank 0 Black
  ++ pawns 1 Black
  ++ pawns 6 White
  ++ backRank 7 White
  where
    backOrder = [Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook]
    backRank r s = [(Position r c, Piece s pt) | (c, pt) <- zip [0..7] backOrder]
    pawns r s    = [(Position r c, Piece s Pawn) | c <- [0..7]]

pieceAt :: Board -> Position -> Maybe Piece
pieceAt b p = Map.lookup p b

putPiece :: Position -> Piece -> Board -> Board
putPiece p pc b
  | isValidPosition p = Map.insert p pc b
  | otherwise       = b

removePiece :: Position -> Board -> Board
removePiece p = Map.delete p

movePiece :: Position -> Position -> Board -> Board
movePiece from to b =
  case Map.lookup from b of
    Nothing -> b
    Just pc -> Map.insert to pc (Map.delete from b)

isPathClear :: Board -> Position -> Position -> Bool
isPathClear b (Position r1 c1) (Position r2 c2) =
  let dr    = signum (r2 - r1)
      dc    = signum (c2 - c1)
      steps = max (abs (r2 - r1)) (abs (c2 - c1))
      mid   = [Position (r1 + i * dr) (c1 + i * dc) | i <- [1 .. steps - 1]]
  in all (`Map.notMember` b) mid
