module Chess.Move
  ( Move(..)
  , promotionAssetPath
  ) where

import Chess.Position (Position)
import Chess.PieceType (PieceType)
import Chess.Side (Side)
import Chess.Piece (Piece(..), pieceAssetPath)

data Move = Move
  { moveFrom      :: Position
  , moveTo        :: Position
  , movePromotion :: Maybe PieceType
  } deriving (Eq, Ord, Show, Read)

promotionAssetPath :: Side -> Maybe PieceType -> Maybe FilePath
promotionAssetPath _ Nothing   = Nothing
promotionAssetPath s (Just pt) = Just (pieceAssetPath (Piece s pt))
