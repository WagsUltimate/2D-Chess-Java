@echo off
cd /d "%~dp0"
cabal test
