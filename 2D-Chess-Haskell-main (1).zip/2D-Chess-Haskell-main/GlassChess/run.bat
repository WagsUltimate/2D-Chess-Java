@echo off
cd /d "%~dp0"
cabal run glass-chess
