module Main where

import qualified Data.Map.Strict as Map
import Data.Char (toLower)
import System.IO (hFlush, stdout)

-- ==========================================
-- Core Data Types
-- ==========================================

data Color = White | Black
  deriving (Eq, Show)

data PieceType = King | Queen | Rook | Bishop | Knight | Pawn
  deriving (Eq, Show)

data Piece = Piece
  { pieceColor :: Color
  , pieceType  :: PieceType
  } deriving (Eq)

-- Coordinates: (row, col) where (0, 0) is top-left (a8) and (7, 7) is bottom-right (h1)
type Coord = (Int, Int)
type Board = Map.Map Coord Piece

data GameState = GameState
  { board    :: Board
  , turn     :: Color
  , gameOver :: Bool
  , winner   :: Maybe Color
  } deriving (Show)

-- ==========================================
-- Display & Formatting
-- ==========================================

opponent :: Color -> Color
opponent White = Black
opponent Black = White

pieceSymbol :: Piece -> Char
pieceSymbol (Piece White King)   = '♔'
pieceSymbol (Piece White Queen)  = '♕'
pieceSymbol (Piece White Rook)   = '♖'
pieceSymbol (Piece White Bishop) = '♗'
pieceSymbol (Piece White Knight) = '♘'
pieceSymbol (Piece White Pawn)   = '♙'
pieceSymbol (Piece Black King)   = '♚'
pieceSymbol (Piece Black Queen)  = '♛'
pieceSymbol (Piece Black Rook)   = '♜'
pieceSymbol (Piece Black Bishop) = '♝'
pieceSymbol (Piece Black Knight) = '♞'
pieceSymbol (Piece Black Pawn)   = '♟'

renderBoard :: Board -> String
renderBoard b = unlines $ header : rows ++ [header]
  where
    header = "    a   b   c   d   e   f   g   h"
    rows   = [renderRow r | r <- [0..7]]
    renderRow r =
      let rankLabel = show (8 - r) ++ " "
          cells     = [cellStr (r, c) | c <- [0..7]]
      in rankLabel ++ unwords cells ++ " " ++ show (8 - r)
    cellStr coord =
      case Map.lookup coord b of
        Just p  -> "[" ++ [pieceSymbol p] ++ "]"
        Nothing -> " . "

-- ==========================================
-- Initial Board Setup
-- ==========================================

initialBoard :: Board
initialBoard = Map.fromList $
     backRank 0 Black
  ++ pawns 1 Black
  ++ pawns 6 White
  ++ backRank 7 White
  where
    order = [Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook]
    backRank r col = [((r, c), Piece col pt) | (c, pt) <- zip [0..7] order]
    pawns r col    = [((r, c), Piece col Pawn) | c <- [0..7]]

initialGame :: GameState
initialGame = GameState
  { board    = initialBoard
  , turn     = White
  , gameOver = False
  , winner   = Nothing
  }

-- ==========================================
-- Coordinate Parsing (Algebraic Notation)
-- ==========================================

-- Parses strings like "e2 e4" or "e2e4"
parseMoveInput :: String -> Maybe (Coord, Coord)
parseMoveInput raw =
  let cleaned = filter (/= ' ') (map toLower raw)
  in case cleaned of
       [fc, fr, tc, tr] -> do
         fromC <- parseCoord fc fr
         toC   <- parseCoord tc tr
         return (fromC, toC)
       _ -> Nothing

parseCoord :: Char -> Char -> Maybe Coord
parseCoord fileCh rankCh =
  let col = fromEnum fileCh - fromEnum 'a'
      row = 8 - (fromEnum rankCh - fromEnum '1')
  in if inBounds (row, col) then Just (row, col) else Nothing

inBounds :: Coord -> Bool
inBounds (r, c) = r >= 0 && r < 8 && c >= 0 && c < 8

-- ==========================================
-- Move Validation Rules
-- ==========================================

isPathClear :: Board -> Coord -> Coord -> Bool
isPathClear b (r1, c1) (r2, c2) =
  let dr    = signum (r2 - r1)
      dc    = signum (c2 - c1)
      steps = max (abs (r2 - r1)) (abs (c2 - c1))
      path  = [(r1 + i * dr, c1 + i * dc) | i <- [1 .. steps - 1]]
  in all (`Map.notMember` b) path

isValidPseudoMove :: Board -> Coord -> Coord -> Piece -> Bool
isValidPseudoMove b from@(r1, c1) to@(r2, c2) (Piece col pt)
  | from == to = False
  | not (inBounds to) = False
  | maybe False ((== col) . pieceColor) (Map.lookup to b) = False
  | otherwise = case pt of
      King ->
        abs (r2 - r1) <= 1 && abs (c2 - c1) <= 1

      Knight ->
        let dr = abs (r2 - r1)
            dc = abs (c2 - c1)
        in (dr == 2 && dc == 1) || (dr == 1 && dc == 2)

      Rook ->
        (r1 == r2 || c1 == c2) && isPathClear b from to

      Bishop ->
        abs (r2 - r1) == abs (c2 - c1) && isPathClear b from to

      Queen ->
        (r1 == r2 || c1 == c2 || abs (r2 - r1) == abs (c2 - c1))
          && isPathClear b from to

      Pawn ->
        let dir        = if col == White then -1 else 1
            startRow   = if col == White then 6 else 1
            target     = Map.lookup to b
            isEmpty    = maybe True (const False) target
            isEnemy    = maybe False ((== opponent col) . pieceColor) target
            oneStep    = (c2 == c1) && (r2 == r1 + dir) && isEmpty
            twoStep    = (c2 == c1) && (r1 == startRow) && (r2 == r1 + 2 * dir)
                         && isEmpty && isPathClear b from to
            diagonalCp = (abs (c2 - c1) == 1) && (r2 == r1 + dir) && isEnemy
        in oneStep || twoStep || diagonalCp

-- ==========================================
-- Check & Checkmate / King Capture Detection
-- ==========================================

findKing :: Board -> Color -> Maybe Coord
findKing b col =
  case [pos | (pos, Piece c pt) <- Map.toList b, c == col && pt == King] of
    (k:_) -> Just k
    []    -> Nothing

isSquareAttacked :: Board -> Coord -> Color -> Bool
isSquareAttacked b target attackerCol =
  any canAttack (Map.toList b)
  where
    canAttack (pos, p) =
      pieceColor p == attackerCol && isValidPseudoMove b pos target p

isInCheck :: Board -> Color -> Bool
isInCheck b col =
  case findKing b col of
    Nothing -> True
    Just k  -> isSquareAttacked b k (opponent col)

applyMoveRaw :: Board -> Coord -> Coord -> Piece -> Board
applyMoveRaw b from to (Piece col pt) =
  let promotedPt = case pt of
        Pawn | (col == White && fst to == 0) || (col == Black && fst to == 7) -> Queen
        _ -> pt
      updatedPiece = Piece col promotedPt
  in Map.insert to updatedPiece (Map.delete from b)

allLegalMovesFor :: Board -> Color -> [(Coord, Coord)]
allLegalMovesFor b col =
  [ (from, to)
  | (from, p) <- Map.toList b
  , pieceColor p == col
  , to <- allCoords
  , isValidPseudoMove b from to p
  , let nextB = applyMoveRaw b from to p
  , not (isInCheck nextB col)
  ]
  where
    allCoords = [(r, c) | r <- [0..7], c <- [0..7]]

-- ==========================================
-- Game Step & Interactive CLI Loop
-- ==========================================

stepGame :: GameState -> (Coord, Coord) -> Either String GameState
stepGame gs (from, to) =
  case Map.lookup from (board gs) of
    Nothing ->
      Left "No piece at starting square."
    Just p | pieceColor p /= turn gs ->
      Left ("It is " ++ show (turn gs) ++ "'s turn.")
    Just p ->
      let legal = allLegalMovesFor (board gs) (turn gs)
      in if (from, to) `notElem` legal
           then Left "Illegal move (invalid pattern, blocked path, or leaves king in check)."
           else
             let nextBoard = applyMoveRaw (board gs) from to p
                 nextTurn  = opponent (turn gs)
                 nextLegal = allLegalMovesFor nextBoard nextTurn
                 inCheck   = isInCheck nextBoard nextTurn
                 noMoves   = null nextLegal
                 isOver    = noMoves
                 winCol    = if noMoves && inCheck then Just (turn gs) else Nothing
             in Right GameState
                  { board    = nextBoard
                  , turn     = nextTurn
                  , gameOver = isOver
                  , winner   = winCol
                  }

gameLoop :: GameState -> IO ()
gameLoop gs = do
  putStrLn ""
  putStrLn (renderBoard (board gs))
  if isInCheck (board gs) (turn gs) && not (gameOver gs)
    then putStrLn ("*** CHECK on " ++ show (turn gs) ++ "! ***")
    else return ()

  if gameOver gs
    then case winner gs of
      Just w  -> putStrLn ("Checkmate! " ++ show w ++ " wins!")
      Nothing -> putStrLn "Stalemate! Draw game."
    else do
      putStr (show (turn gs) ++ " to move (e.g., e2 e4, or 'quit'): ")
      hFlush stdout
      input <- getLine
      let trimmed = map toLower (unwords (words input))
      if trimmed == "quit" || trimmed == "exit"
        then putStrLn "Goodbye!"
        else case parseMoveInput input of
          Nothing -> do
            putStrLn "Invalid format. Use algebraic coordinates like 'e2 e4'."
            gameLoop gs
          Just mv -> case stepGame gs mv of
            Left err     -> do
              putStrLn ("Move rejected: " ++ err)
              gameLoop gs
            Right nextGs -> gameLoop nextGs

main :: IO ()
main = do
  putStrLn "=== 2D Chess (Haskell) ==="
  gameLoop initialGame
